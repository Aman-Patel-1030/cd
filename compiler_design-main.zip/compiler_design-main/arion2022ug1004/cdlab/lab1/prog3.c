#include<stdio.h>

int main() {
	int a=5,b=7,c=8,d=10,s;

	s = a*b + c*d;
	printf("%d",s);

}
