#include<stdio.h>

int main() {
	int i,j,sum;
	float x,y;
	
	i = -103; j = 411; sum = 0; x = -2.35; y = 1e-3;

	if(i<=j) sum -= i;
	else sum += j;

	x = 2.5*x + y;

	return 0;
}
